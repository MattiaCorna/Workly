<form action="upload.php" method="POST" enctype="multipart/form-data"> 
    <input type="file" name="miofile" >
    <input type="submit">
</form>