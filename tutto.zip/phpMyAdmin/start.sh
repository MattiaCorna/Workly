sudo service apache2 start
sudo service mariadb start
#open port