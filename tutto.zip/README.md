# Nome cognome
Mattia Corna

# Titolo
BPIC (Buste paghe in cloud)

# Tagline
La tua busta paga, sempre online, semplice e sicura

# Descrizione
BPiC (Busta Paga Online) è un software aziendale che consente di elaborare, archiviare e consultare le buste paga in modo digitale, sicuro e accessibile da qualsiasi dispositivo

# Descrizione completa
-come utente devo registrarmi per usufruire del sito
-come utente posso decidere di fare un abbonamento mensile
–come utente, subito dopo la registrazione inserisco inizialmente le caratteristiche del mio contratto, che rimangono salvate nel mio account (maggioranza notturna, indennità di malattia, livello dipendente, maggioranza straordinaria, maggioranza festivi e prefestivi, indennità di reperibilità, indennità di trasferta, se hai diritto di tredicesima e/o quattordicesima)
-come utente, subito dopo la registrazione, posso dire di essere uno statale
-come utente aggiungo le ore mensili lavorate al fine della generazione della busta paga
-come utente aggiungo la paga oraria al fine della generazione della busta paga
-come utente aggiungo le eventuali ore di ferie usufruite al fine della generazione della busta paga
-come utente aggiungo le eventuali ore di malattia usufruite al fine della generazione della busta paga
-come utente aggiungo le eventuali ore straordinaree usufruite al fine della generazione della busta paga
-come utente aggiungo le eventuali ore festive lavorate al fine della generazione della busta paga
-come utente aggiungo le eventuali ore prefestive lavorate al fine della generazione della busta paga
-come utente aggiungo le eventuali ore notturne lavorate al fine della generazione della busta paga
-come utente aggiungo le eventuali ore di reperibilità lavorate al fine della generazione della busta paga
-come utente aggiungo le eventuali ore di trasferta lavorate al fine della generazione della busta paga
-come utente posso richiedere di generare la busta paga completa (tasse, stipendio lordo, stipendio netto, se dicembre tredicesima mensilità, se dicembre quattordicesima mensilità, ore ferie maturate, voci variabili generali del mese)
-come utente abbonato posso richiedere la stampa pdf della busta paga
-come utente abbonato posso il pdf della busta paga per email
-come utente abbonato posso visualizzare tutte le mie precedenti buste paghe nell archivio
-come utente abbonato posso rimuovere buste paghe dall archivio
-come utente abbonato posso selezionare due tra le mie buste paghe e confrontare tra loro lo stipendio lordo e netto e le tasse pagate, le ferie, le malattie ecc...

# Target
Qualsiasi persona che vuole visualizzare la sua busta paga in modo semplice e sicuro e vuole salvarsele tutte

# Competitors
software di jethr, paghe open. software di passepartour, Software DoEmploy

# Tecnologie
html, css, php, js, sql

# Link Web App
http://cornamattia5ie.altervista.org/

# link lovable

https://lovable.dev/projects/c8aff4e1-245f-46da-949b-7d1feca308aa?magic_link=mc_717440c4-8441-40aa-9f76-418026aa812f